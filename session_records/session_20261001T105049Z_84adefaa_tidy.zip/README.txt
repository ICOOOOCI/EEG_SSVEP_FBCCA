SSVEP 会话记录（session_20261001T105049Z_84adefaa）

eeg_raw.npz      连续原始EEG：从采集开始到结束的全部LSL通道，未滤波。
                 data           通道 x 样本（原始数据类型，单位同采集软件）
                 timestamps     每个样本的LSL时间（秒），与events.csv同一时钟
                 fs             标称采样率（Hz）
                 channel_names  全部通道名；eeg_channel_indices 为参与分类的通道
trials.npz       逐试次原始EEG窗口（仅参与分类的通道，未滤波）。
                 trial_ids / labels / predictions   标签与预测为1起的目标编号，-1表示未知
                 trial_NNNN_eeg         通道 x 样本
                 trial_NNNN_timestamps  样本LSL时间
                 trial_NNNN_scores      各目标的FBCCA得分
events.csv       事件时间线（提示、闪烁开始/结束、试次结束等）及对应目标和预测。
info.json        会话摘要：模式、配置、准确率/ITR、通道、逐试次结果表。
model.pkl        （仅模式2）个人校准模型，可用 --calibration-file 加载本ZIP。

读取示例（Python）：
    import numpy as np, zipfile
    z = zipfile.ZipFile("session_20261001T105049Z_84adefaa.zip")
    eeg = np.load(z.open("eeg_raw.npz"))
    data, t = eeg["data"], eeg["timestamps"]
